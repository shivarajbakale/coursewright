# @shivarajbakale/ui

The shell around a Notion-style app, for React and Mantine:

- **AppShell**: the frame: a sidebar you drag wider (or move with the arrow keys), hide with ⌘\ or a double click,
  and that becomes a drawer on a narrow screen; the page in a `<main>` under its bar; a right panel that opens and
  closes; a skip link. `useAppShell()` for your own buttons
- **Sidebar**, **SidebarWorkspace**, **SidebarItem** and **SidebarSection**: the workspace switcher, Search, Home and
  Inbox rows with shortcuts and counts, labelled sections, and a footer
- **TopBar**: the page's breadcrumb (the middle folded into "…"), "Edited 5m ago", who's viewing, Share, the
  favourite star and ⋯
- **SettingsDialog**: Notion's settings, sections on the left filtered by a search box, your panels on the right
- **SearchDialog**: Notion's full search, with filters (only titles, created by, in, date, sort), highlighted
  results and recent searches
- **PageTree**: the sidebar's pages nested in pages, with Favourites and Trash, a ⋯ menu and a + on each page,
  drag to reorder and nest (or ⌥ with the arrow keys), and ARIA's tree with arrow-key navigation
- **CommandPalette** and `useCommandPalette()`: ⌘K, grouped results, highlighted matches, an async search
- **IconPicker**: emoji (search, categories, recent, skin tones), a curated set of lucide icons in Notion's
  colours, and an image by upload or link
- **PageHeader**: a page's cover (gallery, upload, reposition), icon and large editable title, with Add icon,
  Add cover and Add comment on hover
- **DatePicker**: Notion's date picker: a typed date, a month calendar, an end date, time, formats, time zone
  and a reminder
- **NestedMenu**, **OptionChip** and **HoverPreview**: Notion's menus with submenus beside them, option pills in
  Notion's ten colours, and a page's hover card
- **TemplatePicker**, **ShareMenu** and **NotificationsInbox**

## Install

```bash
npm i @shivarajbakale/ui @mantine/core @mantine/hooks react react-dom
```

Import the styles once, after Mantine's:

```ts
import '@mantine/core/styles.css';
import '@shivarajbakale/ui/styles.css';
```

## Your app holds the data

Nothing here fetches, routes or stores. Each component takes what to show as props and reports every change
through a callback; the page passes the new state back. A feature appears when its callback is passed: a
`PageTree` without `onMove` can't be dragged, a `PageHeader` without `onCoverChange` offers no cover.

```tsx
import { CommandPalette, PageTree, useCommandPalette } from '@shivarajbakale/ui';

function Sidebar({ pages, pageId, openPage, movePage, createPage }: SidebarProps) {
  const palette = useCommandPalette(); // ⌘K / Ctrl+K opens and closes it
  return (
    <nav aria-label="Sidebar">
      <PageTree
        pages={pages} // [{ id, title, icon?, children? }]
        selectedId={pageId}
        onSelect={openPage}
        onAdd={createPage} // parentId, or null for the top level
        onMove={({ id, parentId, index }) => movePage(id, parentId, index)}
      />
      <CommandPalette
        opened={palette.opened}
        onClose={palette.close}
        search={(query, signal) => api.searchPages(query, { signal })}
        onSelect={(item) => openPage(item.id)}
      />
    </nav>
  );
}
```

## Other languages and right-to-left

Every string the components draw (labels, aria-labels, placeholders, menu items, announcements, empty states,
"Edited 5m ago") comes from one table, `uiMessages`, in English. Wrap the app in `UiLocale` with the strings to replace
and the locale dates are written in; anything you leave out stays English. Only English ships in the package, so
another language costs your app its own table and nothing more. A string that counts or names something is a function.

```tsx
import { UiLocale, type UiMessages } from '@shivarajbakale/ui';

const de: Partial<UiMessages> = {
  untitled: 'Ohne Titel',
  addPage: 'Seite hinzufügen',
  pageOptions: (page) => `Optionen für ${page}`,
  viewing: (count) => (count === 1 ? '1 Person sieht zu' : `${count} Personen sehen zu`),
  editedAgo: (ago) => `Bearbeitet ${ago}`,
};

<UiLocale locale="de-DE" messages={de}>
  <App />
</UiLocale>;
```

- `UiLocale` nests: an inner one's messages are laid over the outer one's. A prop that names a string (`PageTree`'s
  `label`, `CommandPalette`'s `placeholder`) still wins over the table.
- `locale` (a BCP 47 tag, `en-US` by default) is what `Intl` writes dates and times in: the date picker's month and
  weekday names and its digits, "5m ago" (`Intl.RelativeTimeFormat`), the inbox's days. The date picker's week starts
  where the locale's does (`weekStartOf`: Sunday in the US, Monday in Germany, Saturday in Egypt) unless
  `weekStartsOn` says otherwise, and outside en-US its times are written as `Intl` writes them there.
- `uiMessages` is the full list, with the English. The emoji names and categories and the cover gallery's names are
  data: pass your own `emoji` and `covers` to rename them. The lucide icons' names go through `iconName`.

Right to left needs no prop: put `dir="rtl"` on `<html>` (so menus in portals turn too) and Mantine's
`DirectionProvider`. The stylesheets use logical properties (`margin-inline-start`, `inset-inline-end`), so the frame
mirrors: the sidebar on the right, the tree indented to the left, the comments panel on the left. Arrows that point
along the line turn round, and the arrow keys follow what's on screen, read from the element's direction when the key
is pressed:

| Where             | Left to right                        | Right to left                        |
| ----------------- | ------------------------------------ | ------------------------------------ |
| PageTree          | → opens or steps in, ← closes or out | ← opens or steps in, → closes or out |
| PageTree, moving  | ⌥→ nests in the page above, ⌥← out   | ⌥← nests, ⌥→ out                     |
| NestedMenu        | → opens a submenu, ← closes it       | ← opens a submenu, → closes it       |
| Sidebar's edge    | → widens, ← narrows                  | ← widens, → narrows                  |
| DatePicker, icons | → is the next day or icon            | ← is the next day or icon            |

Keyboard shortcuts (⌘K) stay left to right in either direction.

## Touch

`PageTree` pages drag with a finger held on them for a moment (a swipe scrolls), and a long press opens a page's
menu; the mouse keeps the browser's drag and drop. `AppShell`'s drawer, under 768px, closes with a swipe back towards
its edge. What hovering shows (a page's ⋯ and +, a header's add-a-cover, an inbox item's actions) shows without
hover, behind `@media (hover: none)`, and handles grow under `@media (pointer: coarse)`; a mouse sees no change.

## Theming

Everything is drawn with Mantine's CSS variables, and with the Instrument theme's `--app-*` tokens when the page
sets them, so it follows the app's theme and colour scheme. The one palette spelled out is Notion's ten option
colours, with their own values for light and dark.

The full guide, with every prop and live examples, is the Storybook (`pnpm storybook` at the repo root).
