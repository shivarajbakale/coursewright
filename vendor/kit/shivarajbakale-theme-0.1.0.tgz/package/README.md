# @shivarajbakale/theme

The Instrument theme for Mantine. Near-black grounds, every surface closed
with a 1px hairline instead of a shadow, one lime that means "do this",
figures in a monospace, and status drawn as a wash, an edge and an ink. Dark
is the identity; light is its companion.

## Install

```bash
npm i @shivarajbakale/theme @mantine/core react
```

```tsx
import '@mantine/core/styles.css';
import '@shivarajbakale/theme/styles.css';

import { MantineProvider } from '@mantine/core';
import { cssVariablesResolver, theme } from '@shivarajbakale/theme';

export function App({ children }: { children: React.ReactNode }) {
  return (
    <MantineProvider theme={theme} cssVariablesResolver={cssVariablesResolver} defaultColorScheme="dark">
      {children}
    </MantineProvider>
  );
}
```

## Tokens

`cssVariablesResolver` adds `--app-*` variables in both schemes, for anything
drawn rather than written: `--app-surface`, `--app-line`, `--app-accent`,
`--app-input-edge`, `--app-card-shadow` and the `--app-chart-*` series colours.
`@shivarajbakale/grid` and `@shivarajbakale/blocks` pick up `--app-surface`.

`src/theme.ts` explains the reasoning behind each value.

## Touch

Buttons, action icons and segmented controls take `touch-action: manipulation` (a quick second tap is a tap, not a
zoom), and on iOS fields are 16px under a coarse pointer, so focusing one doesn't zoom the page.
