# @shivarajbakale/blocks

A block editor for React and Mantine that behaves like a Notion page, built on
ProseMirror. What Notion does, and so what this does, is recorded in
[docs/notion-editor-observed.md](docs/notion-editor-observed.md).

## Install

```bash
npm i @shivarajbakale/blocks @mantine/core react react-dom
```

Import the styles once, after Mantine's:

```ts
import '@mantine/core/styles.css';
import '@shivarajbakale/blocks/styles.css';
```

## On a page

```tsx
import { BlockEditorView, useBlockEditor } from '@shivarajbakale/blocks';

function Page({ markdown, onSave }: { markdown: string; onSave: (md: string) => void }) {
  const editor = useBlockEditor({
    initial: markdown, // or blocks: [{ type: 'heading', props: { level: 1 }, content: 'Title' }]
    onChange: (e) => onSave(e.toMarkdown()),
    mentions: { search: (q) => people.filter((p) => p.label.includes(q)) },
    media: { uploadFile: (file) => upload(file), linkPreview: (url) => preview(url) },
  });
  return <BlockEditorView editor={editor} blockMenu={{ onComment: (id) => comment(id) }} />;
}
```

`BlockEditorView` draws Notion's menus over the page: the slash menu, the `+`
and grip beside each block (drag to move, drop on a side for columns, click for
the block menu), the panel over selected words, and the `@` and `:` menus.

## The document

Pages hold the document as blocks, never as ProseMirror's nodes:

```ts
interface Block {
  id: string;
  type: string; // 'paragraph', 'heading', 'todo', 'table', …
  props: Record<string, unknown>; // { level: 2 }, { checked: true }, …
  content: InlineContent[]; // runs of text with marks, and inline atoms (mentions, equations)
  children: Block[];
  color?: string; // 'red', 'blue_background', …
}
```

`getBlocks`, `setBlocks`, `getBlock`, `insertBlocks(blocks, refId, 'before' | 'after' | 'child' | 'firstChild')`,
`updateBlock`, `removeBlocks`, `toMarkdown`, `fromMarkdown`, `setMarkdown`,
`subscribe` and `editor.commands` (`turnInto`, `setColor`, `indent`, `outdent`,
`moveUp`, `moveDown`, `duplicate`, `delete`, `toggleMark`, `undo`, `redo`) work
without a view too, so a server can turn markdown into blocks and back.

Markdown out is Notion's: a blank line between blocks, none inside a list,
`- [ ]  ` for to-dos, toggles as bullets, nesting indented four spaces, and no
escaping (`markdown: { escape: true }` turns escaping on).

### HTML, text and printing

```ts
editor.toHtml(); // semantic HTML of the blocks
editor.toHtml({ standalone: true, title: 'Notes' }); // a whole document with a light, printable stylesheet
editor.toText(); // plain text
await editor.print({ title: 'Notes' }); // the browser's print dialog ("Save as PDF")
```

Every built-in block, mark and inline node has an HTML form: lists that nest, to-dos as disabled checkboxes, toggles
as open `<details>`, code with a `language-…` class, equations as MathML, tables, columns, tabs as sections under their
names, media, bookmarks and mentions. Comments are dropped, their words kept. What a person typed is escaped, and
links, images and frames are written only for safe addresses. `pageUrl(id)` gives sub-pages and Link to page an
address. `blocksToHtml(blocks, options)`, `blocksToText(blocks)` and `printHtml(html)` work without an editor.

A block type writes its HTML with `html: { serialize(block, ctx), list? }` beside its `markdown`, and a widget kind with
`toHtml(props)`; both should escape with `ctx.escape` or `escapeHtml`.

## Adding a block type

Every block type, the built-in ones too, is a spec in an extension. A spec says
everything the editor needs: the schema, how it draws, its menu entries, the
markdown typed at a line's start that makes it, what Enter and Backspace do,
and its markdown out and in.

```ts
import { BlockEditor, defaultExtensions, defineBlock, defineExtension } from '@shivarajbakale/blocks';

const rating = defineBlock({
  type: 'rating',
  content: 'none', // or 'inline' text, 'code' text, or { expression } over `nodes` of its own
  props: { stars: { default: 3 } },
  render: (node) => ['div', { class: 'rating' }, '★'.repeat(node.attrs.stars)],
  menu: [{ title: 'Rating', keywords: ['stars'], group: 'Advanced blocks', description: 'Rate something' }],
  shortcuts: [{ match: /^\(([1-5])\)$/, props: (m) => ({ stars: Number(m[1]) }) }],
  children: false,
  markdown: { serialize: (b) => `Rating: ${b.props.stars}/5` },
});

const ratings = defineExtension({
  name: 'ratings',
  blocks: [rating],
  // Read "Rating: 4/5" back into the block.
  markdownRules: [(tokens, i) => /* … */ null],
});

const editor = new BlockEditor({ extensions: [...defaultExtensions(), ratings] });
```

An extension may also bring marks (`defineMark`), inline nodes (mentions,
equations), ProseMirror plugins, key bindings, input rules, markdown-it
plugins, and slash menu actions that are not blocks (`slashActions`). Specs
can take over Enter (`next`, `emptyEnterToText`, `enterIntoChildren`),
Backspace (`backspace: 'text' | 'merge' | 'none'`), nesting (`children`,
`hidesChildren`) and Mod-Enter (`modEnter`); a structured line (a table, columns)
says how it reads as JSON with `json`.

## Comments, find, word count and versions

- **Comments** (`comments: { threads, currentUser, onCreate, onReply, onResolve }`):
  a `comment` mark on words carries thread ids; the threads are the app's. The
  toolbar's Comment, ⌘⇧M and the block menu's Comment open a box; posting asks
  `onCreate(blockId, quote)` for an id, marks the words, and sends the first
  message through `onReply`. Click tinted words for the thread (reply, resolve).
  Call `editor.setCommentThreads(threads)` when they change.
  `<CommentsPanel editor />` lists the open threads and scrolls to one.
- **Find and replace**: ⌘F, and ⌥⌘F with replace (⌘⇧H is already "last
  colour"). Enter and Shift+Enter, or ⌘G and ⌘⇧G, move between matches; match
  case; Replace all is one undo step. Matches are decorations, within a line.
- **Word count**: `editor.stats({ selection? })` →
  `{ words, characters, blocks, readingMinutes }`; `<EditorStats editor />`
  shows it live, for the selection when there is one.
- **Version history**: `editor.snapshot()` → `{ blocks, markdown, at }`.
  `<VersionHistory editor versions onRestore />` previews a version read-only
  with blocks marked added, removed or changed since (by id), and Restore puts
  it back. `diffBlocks(version, current)` is the comparison on its own.

## Notion's other blocks

Tabs are always in the slash menu. The rest come with the option that does
their work and are left out without it (`optionExtensions(options)` lists
them): a **Button** (`onButton(blockId, props)`), a **Synced block**
(`synced: { load(id), save(id, blocks) }`, plus "Copy and sync" in the block
menu), and **Page**, **Link to page** and **Breadcrumb**
(`pages: { search(q), create(title), open(id), breadcrumb?() }`). Tabs write
markdown as each tab's name in bold and its blocks; a synced block as its
blocks; pages as `[Title](page:id)` and `↗ [Title](page:id)`, which read back.

## Widgets: blocks your app draws

An inline database, a chart or a map is a block your app draws. Name the kinds
in `widgets`, and each one gets a slash menu entry. The block keeps the kind and
its `props` (any JSON), and the editor mounts what `render` returns into it,
inside your React tree:

```tsx
const editor = useBlockEditor({
  widgets: {
    database: defineWidget<{ databaseId: string }>({
      label: 'Database - Inline',
      icon: 'table',
      group: 'Database',
      create: async () => ({ databaseId: await store.createDatabase() }),
      render: ({ databaseId }, api) => <InlineDatabase id={databaseId} readOnly={!api.editable} />,
    }),
  },
});
```

`api` also has `blockId`, `update(props)` (an undoable change to the page),
`select()` and `remove()`. The block is selected as one unit (with the arrow
keys, its handle, or a click on its edge), and Enter starts a line below it.
Copying, pasting, duplicating and dragging keep its props. Keys and typing
inside it are left to your app. In markdown it's an HTML comment,
`<!-- widget:database {"databaseId":"db1"} -->`, which reads back as the same
block. This package never imports `@shivarajbakale/grid`; the app brings the
grid.

## Ask AI

`ai: { run({ instruction, selection, document, signal }) }` answers with a
string or an async iterable of pieces (no AI SDK is bundled; call your own
model). Space in an empty line, ⌘J, the slash menu's Ask AI or the toolbar
open a prompt with quick actions (Improve writing, Fix spelling & grammar,
Make shorter, Make longer, Summarize, Translate…, Continue writing); the answer
streams into a preview to insert below or put in place of the selection.
Escape aborts `signal`.

## Collaboration

```ts
import * as Y from 'yjs';
import { collab } from '@shivarajbakale/blocks/collab';

const editor = useBlockEditor({ collab: collab({ doc, awareness, user: { name: 'Ada', color: '#1c5fb8' } }) });
```

`yjs`, `y-prosemirror` and `y-protocols` are optional peer dependencies, only
needed by a page that imports `@shivarajbakale/blocks/collab`; the main entry
never imports them. The shared document wins over `initial` (which only fills
an empty one); undo and redo take back your own changes only; others' carets
show named, in their colour.

## Other languages and right-to-left

Every string the editor draws (the slash menu, placeholders, aria-labels,
menus, panels, the word count) comes from `blocksMessages`, in English. Pass the
ones to replace as `messages`, with `locale` for dates and numbers (`en-US` by
default), to `useBlockEditor` or `new BlockEditor()`, or wrap the page in
`BlocksLocale`. Strings that count or name something are functions. Only
English ships in the package.

```tsx
import { BlocksLocale, type BlocksMessages } from '@shivarajbakale/blocks';

const de: Partial<BlocksMessages> = {
  textEmpty: '„/“ für Befehle',
  heading: (level) => `Überschrift ${level}`,
  words: (n, x) => `${x} ${n === 1 ? 'Wort' : 'Wörter'}`,
};

<BlocksLocale locale="de-DE" messages={de}>
  <Page />
</BlocksLocale>;
```

A block type's `menu` title and description, and its `placeholder`, may be
functions of the messages (`title: (m) => m.quote`); `menuEntries()` gives
them back read. For right to left, put `dir="rtl"` on `<html>` (or any element
above the editor): the stylesheet uses logical properties, the block handle,
menus and toolbar sit and open on the right, the toggle arrow turns, and tab
lists follow the arrow keys as they point. Code blocks stay left to right.
`toHtml({ standalone: true, lang, dir })` marks an exported page.

## Touch

There is no hover under a finger, so the + and the drag grip come up beside the block it touches. The grip takes the
finger at once to drag the block (a tap opens its menu); anywhere else a swipe scrolls. Under a coarse pointer the
grip is 24px wide, the tools hovering shows are always shown, and the slash, mention and formatting menus stay on a
phone's screen. A mouse sees no change.

## Built in

Text, headings 1 to 4 and toggle headings, bulleted, numbered and to-do lists,
toggles, quotes, callouts, dividers, code (thirty languages, highlighted),
simple tables, 2 to 5 columns, tabs, block and inline equations (KaTeX), a
table of contents, image, video, audio, file, web bookmark and embed, and with
their options buttons, synced blocks, page blocks and widgets; marks for bold, italic,
underline, strikethrough, code, links, colour and comments; mentions of dates,
people and pages; emoji. Notion's databases come from `@shivarajbakale/grid`,
put on a page as a widget.

Try it: `pnpm docs` at the repo root, then the blocks tab.
