# Notion's page editor, as observed

What Notion's page and block editor does, recorded on 2026-10-22 in Chrome,
dark theme, in a throwaway page made for this ("Editor test (Claude, safe to
delete)", in the user's Private pages). When the work was done that page, and
the one sub-page it ended up holding, were moved to Trash. No other page was
edited. It is the reference for our own block editor library. Everything here
was seen from the outside: screenshots, the rendered page's layout and computed
styles, the visible text of menus, keyboard and mouse use, and the clipboard
data the page itself writes on copy. Notion's code, stylesheets, icons and
fonts were not read or copied, and must not be: we build the same behaviour
with our own code and tokens.

Measured sizes are CSS pixels at the browser's zoom on that day. Notion's root
text measured 16px there (body text 16px), so read sizes as proportions of the
body text rather than as absolutes.

Each item says how sure it is: **seen** (watched it happen), **measured** (read
from the rendered page), or **not checked**.

A note on method: the Chrome window was often covered while this ran, and a
hidden tab gets no real key presses. Text was typed with the browser's own
insert-text command (which Notion treats as typing, markdown shortcuts
included); Enter, Backspace and Tab were real key presses when the tab was
visible; shortcuts with ⌘/⌥/⇧ were synthetic key events. Where a synthetic key
did nothing, the result says "no effect seen" rather than "not supported".

## The editor as a whole

- **One editable surface.** The whole page (title and every block) sits inside
  one `contenteditable` root (`role="group"`, `aria-roledescription="editor"`);
  each block's text is its own editable leaf with `role="textbox"`. Selection
  can run across blocks. (measured)
- **Blocks are windowed.** On a long page, blocks far above or below the view
  are not in the DOM. (measured)
- **Converting a block's type gives it a new block id**: a bullet turned into
  text by Backspace came back with a different id. (measured)

## Page shell

| Part | Value | How |
|---|---|---|
| Title placeholder | "New page" (also the tab title until named) | seen |
| Title | 40px, weight 700, line height 48px, 8px side padding | measured |
| Above the title on hover | "Add icon", "Add cover", "Add comment" (a page without a description also shows "Add description") | seen |
| Empty new page | the body has no blocks; a bar at the bottom: "Get started with" · Ask AI, AI Meeting Notes, Database, Form, Templates, "…". Enter in the title makes the first block | seen |
| Body width, normal | 720px column, centred (in a 1455px frame) | measured |
| Body width, Full width | 1263px: the frame less about 96px each side. The toggle is under ⋯ › Appearance & layout › Full width (with Ag Default / Ag Serif / Ag Mono, Small text, Table of contents, Page discussions, Inline comments) | measured |
| Page background | rgb(25, 25, 25); body text rgb(240, 239, 237) | measured |
| Font | system sans (`ui-sans-serif, -apple-system, …`); code in `SFMono-Regular, Menlo, Consolas, "PT Mono", …` | measured |
| Right edge | a small outline of the headings (thin dashes) at the far right of the window | seen |

### Text sizes

| Block | Font size | Weight | Line height | Space above the text |
|---|---|---|---|---|
| Text | 16px | 400 | 24px (1.5) | 6px; block 40px tall for one line |
| Heading 1 | 30px | 600 | 39px | 30px; block 79px |
| Heading 2 | 24px | 600 | 31.2px | 26px; block 67px |
| Heading 3 | 20px | 600 | 26px | 22px; block 58px |
| Heading 4 | 18px | 600 | 23.4px | 18px; block 51px |
| Lists, to-do, toggle | 16px | 400 | 24px | 1px between items (30px per one-line item); 6px before the first item after a non-list block |
| Code | 13.6px (0.85em) mono | 400 | 20.4px | block has 8px padding |
| Simple table cell | 14px | 500 in the header-looking first row | 20px | |

Heading 4 exists (slash menu "Heading 4", shortcut `#### `). (measured)

Blocks have no margins: the gap comes from padding inside each block, so
blocks touch edge to edge. (measured)

## Left gutter: the block handles

- **On hover** two buttons appear left of the block's first line: **+**
  (24×24, 52px left of the text) and **⋮⋮** (18×24, ending 10px left of the
  text). Icon colour rgb(125, 122, 117), 4px radius. (measured)
- Tooltips (their accessible names): **+** "Click to add below. Option-click
  to add a block above"; **⋮⋮** "Drag to move, click to open menu". (measured)
- **Clicking +** adds an empty block below and opens the slash menu at once;
  the new block's placeholder reads "Type to filter…" and what you type
  filters the menu without a "/". (seen)
- On a code block the handles sit beside the block's top, and a small toolbar
  shows in the block's top-right: language ("JavaScript ▾"), Copy code to
  clipboard, Wrap code, and "…" (Open block actions menu). (seen)

## Placeholders

| Where | Placeholder | How |
|---|---|---|
| Focused empty text block | "Press ‘space’ for AI or ‘/’ for commands" | measured |
| Unfocused empty text block | none shown | measured |
| Heading 1 / 2 / 3 / 4 | "Heading 1" / "Heading 2" / "Heading 3" / "Heading 4" | measured |
| Bulleted / numbered list item | "List" | measured |
| To-do | "To-do" | measured |
| Toggle | "Toggle" | measured |
| Empty toggle's body (when open) | "Empty toggle. Click or drop blocks inside." | measured |
| Quote | "Empty quote" | measured |
| Toggle heading 1 | "Heading 1" | measured |
| After typing "/" | "Type to search" shown right after the slash, inside the text | seen |
| Block opened from + | "Type to filter…" | measured |
| Callout | no visible placeholder; the 💡 icon and an empty line | seen |

## Markdown shortcuts at the start of a line

Typed at the very start of a text block. The marker disappears and the block
changes type. (seen, each)

| Typed | Result |
|---|---|
| `# ` `## ` `### ` `#### ` | Heading 1 / 2 / 3 / 4 |
| `- ` `* ` `+ ` | Bulleted list |
| `1. ` | Numbered list ("1.") |
| `i. ` | Numbered list, shown with "i." |
| `a. ` | **nothing**: stays text "a. X" |
| `[] ` and `[ ] ` | To-do |
| `> ` | **Toggle** (not quote) |
| `" ` | Quote |
| `| ` | Quote |
| `---` | Divider at once, no space needed; the caret moves to a new text block below |
| ```` ``` ```` | Code block at once, no space needed |
| `$$x$$` | inline equation (see below), not a block equation |
| `# >` etc. | shown as the hint for Toggle heading 1/2/3 in the slash menu (not tried typed) |

**Gotcha:** Backspace on an empty Heading 1 that is the page's first block
sent the caret into the page title, and the next shortcut was typed into the
title. (seen)

## Inline markdown

Typed in a text block; it converts when the closing mark is typed. (seen, each)

| Typed | Result |
|---|---|
| `**b**` | bold (weight 600) |
| `__w__` | bold |
| `*i*` | italic |
| `_u_` | italic |
| `` `c` `` | inline code: mono, 85% size, padding 0.2em 0.4em, 4px radius, a faint grey background and red text |
| `~s~` | strikethrough |
| `~~d~~` | **nothing**: stays literal |
| `$x$` | nothing |
| `$$x$$` | inline equation (KaTeX-style math, not editable as text; the caret moves past it) |
| `==h==` | nothing |
| `[t](https://a.com)` | nothing when typed (it does work when pasted) |
| `->` `<-` | → ← |
| `--` | — (em dash) |
| `<=` `>=` `!=` | ≤ ≥ ≠ |
| `...` | … |
| `(c)` | nothing |

## Keyboard

| Key | Result | How |
|---|---|---|
| Enter in the middle of text | splits the block: text before stays, text after goes to a new block of the same type below | seen |
| Enter at the end of a heading or quote | new **text** block below (a quote does not continue) | seen |
| Enter at the end of a list item / to-do | new empty item of the same type | seen |
| Enter on an empty bulleted/numbered/to-do item at top level | turns it into a text block | seen |
| Enter on an empty **nested** to-do with nothing after it | outdents it one level first (stays a to-do); Enter again converted it to text (it then had siblings after it) | seen |
| Enter at the end of an open toggle's text | the caret goes inside the toggle, into its first child | seen |
| Enter inside a code block | a new line in the code | seen |
| Backspace at the start of a bullet, number, to-do or quote with text | turns it into a text block, keeps the text | seen |
| Backspace at the start of a text block | merges its text onto the end of the block above | seen |
| Backspace at the start of a nested bullet | turns it into text, still nested (indent kept) | seen |
| Backspace at the start of a Heading 2 with text | merged its text into the text block above (no "turn into text" step first) | seen |
| Tab | nests the block under the block above it (as its last child): seen under a bulleted item, numbered item, to-do, quote and text. Under a heading: no effect | seen |
| Shift+Tab | outdents one level | seen |
| Tab in a code block | not checked (synthetic key had no effect) | not checked |
| Esc while typing | ends text editing and selects the block (blue halo); Esc again clears it | seen |
| ↓ / ↑ with a block selected | moves the selection to the next / previous block | seen |
| Shift+↓ / Shift+↑ | grows the block selection | seen |
| Enter with blocks selected | back to text editing, caret at the end of the first selected block | seen |
| ⌘⇧↑ / ⌘⇧↓ with a block selected | moves the block up / down one | seen |
| ⌘⇧↑ with only a caret | no effect seen (synthetic key) | seen |
| ⌘D | duplicates the block, the copy goes right below | seen |
| ⌘A once | selects all text of the current block | seen |
| ⌘A twice | selects every top-level block on the page (block selection, no text range) | seen |
| Backspace with all blocks selected | deletes them all; the page goes back to the empty-page state | seen |
| ⌘Enter in a to-do | ticks / unticks it | seen |
| ⌘Enter in a toggle | not checked | not checked |
| ⌘⌥1 / 2 / 3 | Heading 1 / 2 / 3 | seen |
| ⌘⌥4 | To-do | seen |
| ⌘⌥5 | Bulleted list | seen |
| ⌘⌥6 | Numbered list | seen |
| ⌘⌥7 | Toggle | seen |
| ⌘⌥8 | Code | seen |
| ⌘⌥9 | **Page**: the block becomes a sub-page (a page link with its text as the title) | seen |
| ⌘⌥0 (text) | not checked | not checked |
| ⌘B / ⌘I / ⌘U | bold / italic / underline | seen |
| ⌘E | inline code | seen |
| ⌘⇧S | strikethrough | seen |
| ⌘⇧X | also strikethrough | seen |
| ⌘⇧H | applies the last used colour (here "Yellow background", shown as "Last used" in the colour menu with ⌘⇧H beside it) | seen |
| ⌘⇧M | opens a comment box ("Add a comment...") beside the selection, the text gets a faint yellow tint; Esc cancels and the tint goes | seen |
| ⌘K with text selected | link popover: a field "Paste link or search pages", then "Recents" (pages). Typing a URL shows "Link to web page"; Enter makes the link | seen |
| ⌘Z | undoes typing in bursts, by pauses rather than by word: after " one two three" (pause) " four", one ⌘Z removed " four" | seen |
| ⇧⌘Z | redoes | seen |
| ⌘/ | no effect seen (synthetic key) | seen |
| ⌘⇧L | not tried: it switches Notion's theme, a user setting | not checked |
| Shift+Enter, Delete at the end of a block, ↑/↓ keeping the caret column | not checked | not checked |

## Block selection

- **Look:** each selected block gets a halo inset 2px from the block, rgba(35,
  131, 226, 0.14), 4px radius, no border. It fades out when cleared.
  (measured)
- **After a paste**, the pasted blocks are left selected, and an AI popover
  ("Suggested actions": Paste, Improve writing, Proofread, Reformat, "Edit with
  AI ⌘^E") opens to the right. We do not want the AI part. (seen)
- Rectangle selection by dragging from the margin, and Shift+click: not
  checked. (not checked)

## Slash menu

Opens when "/" is typed **as its own keystroke** at the start of a block or
after a space. Typing "/" glued to the end of a whole inserted word did not
open it. (seen)

| Part | Value | How |
|---|---|---|
| Size | 324px wide; 376px high when full (list scrolls inside, 334px visible) | measured |
| Surface | rgb(37, 37, 37), 10px radius, a 1px ring rgb(56, 56, 54) plus a soft drop shadow | measured |
| Position | left edge about 12px left of the caret; opened **above** the line when the line was low in the window | measured |
| Items | 32px tall; icon, name, the markdown shortcut right-aligned in muted text | measured |
| Highlight | the first item starts highlighted (faint white fill); keyboard moves show a blue ring around the item | seen |
| Description | the highlighted item shows a tooltip to the right of the menu (list below) | seen |
| Footer | "Close menu" with "esc" at the bottom, always shown | seen |
| Filtering | the text after "/" filters, fuzzy: "/red" matched "Numbered list" | seen |
| No results | the list empties but "Close menu" stays; the menu closes on the 4th character in a row with no match ("/qz", "/qzx", "/qzxq" stayed open, "/qzxqz" closed) | seen |
| Esc | closes the menu; the typed "/…" text stays in the block | seen |
| Picking a type in a block that has text | inserts the new block **below** (the "/query" text is removed); picking in an empty block turns that block | seen |

### Items in order

**Suggested:** AI Meeting Notes; HTML · Embeds (New)

**Basic blocks:** Text; Heading 1 `#`; Heading 2 `##`; Heading 3 `###`;
Heading 4 `####`; Bulleted list `-`; Numbered list `1.`; To-do list `[]`;
Toggle list `>`; Page; Callout; Quote `"`; Table; Divider `---`; Link to page

**Media:** Image; Video; Audio; Code ```` ``` ````; File; Web bookmark

**Database:** Table view; Board view; Gallery view; List view; Feed view;
Dashboard view (New); Calendar view; Timeline view; Map view (New); Vertical
bar chart; Horizontal bar chart; Line chart; Donut chart; Number chart; Form;
Database - Inline; Database - Full page; Linked view of data source

**Advanced blocks:** Table of contents; Block equation; Button; Breadcrumb;
Tabs (New); Synced block; Toggle heading 1 `# >`; Toggle heading 2 `## >`;
Toggle heading 3 `### >`; 2 columns; 3 columns; 4 columns; 5 columns; (then AI
Meeting Notes, Code - Mermaid, AI Block)

**Inline:** Mention a person; Mention a page or data source; Date or reminder;
Emoji; Inline equation

**Embeds:** Embed; HTML (New); then about 50 services (Google Drive, Tweet,
GitHub Gist, Google Maps, Figma, … Jira, GitHub)

**Synced Databases** (Asana, GitLab, GitHub) and **Import** (CSV, Text and
Markdown, Asana, Confluence, Google Docs, Trello, Dropbox Paper, Evernote,
Workflowy, Word, Monday, Quip, ZIP, PDF). (seen, all)

### Descriptions (tooltip on the highlighted item)

Text "Just start writing with plain text"; Heading 1 "Big section heading";
Heading 2 "Medium section heading"; Heading 3 "Small section heading"; Heading
4 "Smaller section heading"; Bulleted list "Create a simple bulleted list";
Numbered list "Create a list with numbering"; To-do list "Track tasks with a
to-do list"; Toggle list "Toggles can hide and show content inside"; Page
"Embed a sub-page inside this page"; Callout "Make writing stand out"; Quote
"Capture a quote"; Table "Add simple tabular content to your page"; Divider
"Visually divide blocks"; Link to page "Link to an existing page"; Image
"Upload or embed with a link"; Video "Embed from YouTube, Vimeo…"; Audio "Embed
from SoundCloud, Spotify…"; Code "Capture a code snippet"; File "Upload or
embed with a link"; Web bookmark "Save a link as a visual bookmark". (seen)

### Filter examples

| Typed | Results |
|---|---|
| `/h2` | Heading 2; Toggle heading 2; then "Heading 2 · Turn into"; "Toggle heading 2 · Turn into" |
| `/todo` | To-do list |
| `/bul` | Bulleted list |
| `/code` | Code; CodePen · Embeds; Code - Mermaid |
| `/col` | 2/3/4/5 columns; Toggle list |
| `/tog` | Toggle list; Toggle heading 1/2/3; Tabs |
| `/date` | Date or reminder |
| `/red` | "A Red text"; Red background; Numbered list; "Numbered list · Turn into" |
| `/blue` | Blue text; Blue background |
| `/color` | all ten text colours then all ten backgrounds |
| `/turn` (block with text) | every type as "X · Turn into": Text, Heading 1–4, Page, Page in, Bulleted list, Numbered list, To-do list, Toggle list, Code, Quote, Callout, Block equation, Synced block, Toggle heading 1–4, 2–5 columns |
| `/turn` (empty block) | nothing |

So the slash menu also carries **colours** and **Turn into** actions for the
current block, but only when the block has text. (seen)

## Block menu (click ⋮⋮)

265px wide, opens to the left of the handle, a search field focused
("Search actions…"). Top to bottom: (seen)

1. Header: the block's type ("Text")
2. **Turn into** ›
3. **Color** ›
4. **Copy link to block** ⌘⌃L
5. **Duplicate** ⌘D
6. **Move to** ⌘⇧P
7. **Delete** Del
8. **Comment** ⌘⇧M
9. **Suggest edits** ⌘⇧⌥X
10. **Ask AI** ⌘J
11. **Skills** ›
12. Footer: "Last edited by <name>", "Today at 4:42 PM", "3 words, 21 characters"

**Turn into ›** Text, Heading 1, Heading 2, Heading 3, Heading 4, Page, Page
in, Bulleted list, Numbered list, To-do list, Toggle list, Code, Quote,
Callout, Block equation, Synced block, Toggle heading 1, Toggle heading 2,
Toggle heading 3, Toggle heading 4, 2 columns, 3 columns, 4 columns, 5
columns. (seen)

**Color ›** three groups: **Last used** (Yellow background ⌘⇧H), **Text
color** (Default, Gray, Brown, Orange, Yellow, Green, Blue, Purple, Pink, Red,
each "X text" with an "A" swatch), **Background color** (Default … Red, each
"X background"). Picking applies to the whole block and closes the menu.
(seen)

Page ⋯ menu, for reference: Copy link ⌘⌥L, Copy page contents, Duplicate ⌘D,
Move to ⌘⇧P, Version history, Updates & analytics, Appearance & layout, Use
with AI, Suggest edits, Notify me, Lock page, Move to Trash, More. (seen)

Dragging a block (drop line, columns from side drops, nesting by drop): not
checked; the drag could not be driven. (not checked)

## Colours (dark theme)

Swatches in the colour menu are 1px inset rings in a tint of the colour; the
block result matches the swatch. (measured)

| Name | Text colour | Background |
|---|---|---|
| Default | rgb(240, 239, 237) | none |
| Gray | rgb(125, 122, 117) | rgb(56, 56, 54) |
| Brown | rgb(159, 118, 90) | rgb(69, 54, 45) |
| Orange | rgb(210, 123, 45) | rgb(83, 54, 31) |
| Yellow | rgb(203, 148, 52) | rgb(80, 68, 37) |
| Green | rgb(80, 148, 110) | rgb(38, 61, 48) |
| Blue | rgb(56, 125, 201) | rgb(35, 56, 80) |
| Purple | rgb(154, 107, 180) | rgb(60, 45, 71) |
| Pink | rgb(193, 76, 138) | rgb(78, 43, 60) |
| Red | rgb(207, 81, 72) | rgb(80, 44, 41) |

A background colour fills the whole block row with rounded corners. The
inline highlight from ⌘⇧H used a yellow tint (not the solid block value). The
light theme was not measured (it would mean changing the user's setting).
(measured; light not checked)

## Selection toolbar

Selecting text opens a **vertical panel** (not a one-line bar), placed beside
the selection, about 220px wide, surface rgb(37, 37, 37). Top to bottom: (seen)

1. **Normal Text ›** (Turn into, showing the current type)
2. A row: **A** (colour), **B**, *I*, U, **Clear format** (Tx)
3. A row: link, strikethrough, code (`</>`), equation (√x), "…" more
4. **Comment**, then two icon buttons (react with emoji, suggest edit)
5. **Skills** (AI: Improve writing, Proofread, Explain, Reformat) and an "Edit
   with AI ⌘^E" field

Items are 32×28 icon buttons, 4px gaps. The tooltips of the icon buttons were
not read (hover could not be driven reliably). (measured, seen)

**Links** render in the text colour with a thin underline (0.05em, offset 10%)
and the linked text at 0.7 opacity. (measured)

## Mentions, dates and emoji

- **"@"** opens a 330×376 menu: **Date** (Today; Remind me — Tomorrow 9am),
  **People** (workspace members and guests, then "Invite…"), **Link to page**
  (recent pages, "15 more results"), **New page** (Add new sub-page, Add new
  page in…). Typing filters every group: "@tod" showed Date "Today — October
  22, 2026", Invite "tod"…, matching pages, New "tod" sub-page, and "Give
  search feedback". (seen)
- **"@today" + Enter** inserts a date mention shown as "@Today" (relative),
  as one non-editable token, followed by a space. (seen)
- **":"** alone shows nothing; **":" plus one letter** opens an emoji grid
  (403×352) filtered by name ("smiling face with open mouth" …); ":smi" cut
  it to one row. Enter inserts the first emoji in place of ":smi". (seen)

## Block types: look

| Block | Look | How |
|---|---|---|
| Bulleted list | glyph per depth: • then ◦ then ▪ (then repeats); the glyph sits in a 24px box left of the text, text has 6px left padding | measured |
| Numbered list | "1." "2." at the top level, "a." at the second; `i. ` gives roman | measured, seen |
| To-do | 16×16 box, 1.5px radius, 1.5px border rgb(230, 229, 227) when open; ticked: fill rgb(39, 131, 222) with a white check, the text struck through at 0.7 opacity | measured |
| Toggle | a ▸ / ▾ triangle left of the text; open toggle's body is indented under the text | seen |
| Toggle heading | the heading with a ▸ in front | seen |
| Quote | 3px solid bar in the text colour on the left, 14px padding each side of the text | measured |
| Callout | rgb(56, 56, 54) background, 10px radius, 12px padding, 💡 icon by default; holds child blocks (a text line inside) | measured |
| Divider | 13px tall block with a 1px line rgba(255, 255, 235, 0.1) | measured |
| Code | dark panel, mono 13.6px, syntax colours; language auto-picked ("JavaScript" for `const a = 1;`); toolbar on hover: language ▾, copy, wrap, … | seen, measured |
| Block equation | centred rendered math (E = mc²) | seen |
| Simple table | new from the slash menu: 3×3 grid, thin borders, no header styling | seen |
| Columns | "2 columns" makes two empty side-by-side columns, each with an empty text block; nothing visible until filled | seen |
| Table of contents | each heading as a muted, underlined link, indented by level (about 28px per level) | seen |
| Image / Web bookmark / Embed (empty) | a 65px grey row with an icon and "Add an image" / "Add a web bookmark" / "Embed anything (PDFs, Google Docs, Google Maps, Spotify…)" | seen |
| Page (sub-page) | page icon and the title, bold and underlined, in the flow of blocks | seen |

## Copy: what goes on the clipboard

With every block selected (⌘A ⌘A), a copy writes `text/plain`, `text/html`,
and two private Notion types. (measured, from the page's own copy event)

The **text/plain** is Markdown:

```
### X

#### X

- X
- X
- X
1. X

a. X

1. X
- [ ]  X
- [ ]  X
- X
    
    > X
    > 
    
    ---
    

**b** *i* *u* `c` ~~s~~ ~~d~~ $x$ ==h== → ← — (c) ≤ ≥ ≠ … t **w** 

~~d~~ 

$x$

```jsx
const a = 1;
b
```

Item//
```

- One blank line between blocks; **none between consecutive list items, even
  of different list types** (bullets then "1." with no blank line).
- Headings `#`…`####`; bullets `- `; numbers `1. `; to-dos `- [ ]  ` (two
  spaces after the bracket).
- A **toggle is written as a bullet** ("- X") with its children indented by
  4 spaces.
- A quote is `> X` followed by an empty `> ` line.
- Divider `---`; code is fenced with the language (`jsx` for JavaScript).
- Bold `**`, italic `*`, inline code backticks, strikethrough `~~`.
- An inline equation becomes `$x$`.
- **No escaping:** literal text that looks like Markdown ("~~d~~", "$x$",
  "==h==") is written as is; a literal `[t](https://a.com)` typed as plain
  text came out as just "t" in text/plain and as a real link in text/html, so
  Notion builds the HTML from the Markdown.

The **text/html** is plain semantic HTML: `<h3>`, `<h4>`, `<ul><li>`, `<ol>`,
`<p>`, to-dos as `<li><p>[ ]  X</p></li>`, `<blockquote><p>`, `<hr>`,
`<strong>`, `<em>`, `<code>`, `<s>`, `<a href>`, code as `<pre><code
class="language-jsx">`, and a trailing `<!-- notionvc: … -->` comment.

## Paste: Markdown in, blocks out

A synthetic paste of this Markdown as text/plain into an empty block:
(seen)

| Pasted | Block |
|---|---|
| `#`, `##`, `###`, `####` | Heading 1–4 |
| `**bold**`, `*italic*`, `` `code` ``, `~~strike~~`, `[link](url)` | formatted text and a real link |
| `- a` / `  - b1` / `    - b2` | bullets nested two levels |
| `1. one` / `2. two` / `   1. two-one` | numbered, nested ("a.") |
| `- [ ] todo` / `- [x] done` | to-dos, the second ticked |
| `> quote` | Quote |
| ```` ```python ```` fence | Code |
| `---` | Divider |
| a pipe table | simple Table, 2×2 |
| `$$` … `$$` on their own lines | Block equation |
| `<details><summary>` HTML | plain text, the tags shown literally |

Pasting several paragraphs into a block that already has text merges the
first pasted block into that text. (seen)

## Not checked

Shift+Enter; Delete at the end of a block; ↑/↓ caret column; ⌘Enter on a
toggle; ⌘⌥0; Tab inside code; mouse rectangle selection and Shift+click;
dragging blocks (drop indicator, columns, nesting); Option-click on +; the
selection toolbar's tooltips and colour panel (its "A" button); code
language picker list and caption; simple table header row/column toggles and
adding rows/columns; Link to page picker; light theme colours.

## What our library must do

- [ ] One editable surface for title and blocks, text selection across blocks.
- [ ] Placeholders: "Press ‘space’ for AI or ‘/’ for commands" (we will say
      "Type ‘/’ for commands") on the focused empty text block only; type
      names on empty headings, lists, to-do, toggle, quote.
- [ ] Line-start shortcuts: `#`–`####`, `-`/`*`/`+`, `1.`, `[]`/`[ ]`, `>`
      (toggle), `"` and `|` (quote), `---`, ```` ``` ````; `a.` does nothing.
- [ ] Inline shortcuts: `**`/`__` bold, `*`/`_` italic, backtick code, `~`
      strike, `$$x$$` equation; `->` `<-` `--` `<=` `>=` `!=` `...`
      replacements.
- [ ] Enter splits; Enter on an empty list item outdents if nested and last,
      else turns it into text; Enter after a heading or quote gives text;
      Enter at the end of an open toggle goes inside it.
- [ ] Backspace at start: list/to-do/quote → text (indent kept); text →
      merge into the block above.
- [ ] Tab nests under the block above (any type but headings); Shift+Tab
      outdents.
- [ ] Esc selects the block; arrows move and Shift+arrows grow the block
      selection; Enter goes back to text; Backspace deletes; ⌘⇧↑/↓ move;
      ⌘D duplicates; ⌘A once = block text, twice = all blocks.
- [ ] ⌘⌥1–9 turn into H1, H2, H3, to-do, bullet, number, toggle, code, page;
      ⌘Enter ticks a to-do.
- [ ] ⌘B/I/U, ⌘E code, ⌘⇧S strike, ⌘⇧H last colour, ⌘K link popover,
      ⌘Z/⇧⌘Z with burst-level undo.
- [ ] Slash menu: grouped list with shortcut hints, descriptions as a side
      tooltip, fuzzy filter, "Close menu esc" footer, closes after 4
      unmatched characters, Esc keeps the text, flips above near the bottom;
      also offers colours and "Turn into" for a block with text.
- [ ] Gutter: + (adds below and opens the filter menu; ⌥ adds above) and ⋮⋮
      (drag; click opens the block menu: Turn into, Color, Copy link, Duplicate,
      Move to, Delete, Comment …, with shortcuts and a "Last edited" footer).
- [ ] Ten colours, text and background, in the order Default, Gray, Brown,
      Orange, Yellow, Green, Blue, Purple, Pink, Red, plus "Last used".
- [ ] Copy writes Markdown text/plain in exactly the format above (blank line
      between blocks, none inside lists, `- [ ]  `, toggles as bullets,
      4-space child indent, fenced code with language) and matching HTML.
- [ ] Paste of Markdown text makes real blocks (headings, nested lists,
      to-dos with [x], quote, code, divider, table, $$ equation, inline marks
      and links).
- [ ] Block selection halo: 2px inset, blue at 14%, 4px radius.
- [ ] Bullets • ◦ ▪ by depth; numbers 1. → a. → i.; ticked to-do struck and
      dimmed with a blue box.
