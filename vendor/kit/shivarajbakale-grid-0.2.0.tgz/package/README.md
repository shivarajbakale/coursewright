# @shivarajbakale/grid

A spreadsheet grid for React and Mantine, after Notion's table. It draws any
number of rows from data the page holds:

- windowed rows and columns, a sticky header, frozen columns
- resize and reorder columns, a menu on each header (sort, filter, group, rename, insert, duplicate, delete)
- a cell selection driven by mouse and keyboard, copy as tab-separated text, paste, fill, undo
- row ticks with Shift-click ranges, groups that open and close, a footer of calculations
- sub-items nested under their rows, indented with a toggle, as Notion's
- views as tabs, with their settings beside them
- the same rows as a list, a board, a gallery, a feed, a calendar or a timeline

## Install

```bash
npm i @shivarajbakale/grid @mantine/core react react-dom
```

Import the styles once, after Mantine's:

```ts
import '@mantine/core/styles.css';
import '@shivarajbakale/grid/styles.css';
```

## On a page

The grid never holds the rows. It asks for them by index, so the page can keep
them in memory, page them in from an API (`readRows`), or both.

```tsx
import { DataGrid, type GridColumn } from '@shivarajbakale/grid';

interface Company {
  id: string;
  name: string;
  country: string;
}

const columns: GridColumn<Company>[] = [
  { id: 'name', label: 'Name', emphasis: true, render: (c) => c.name, text: (c) => c.name, value: (c) => c.name },
  { id: 'country', label: 'Country', render: (c) => c.country, text: (c) => c.country },
];

function Companies({ rows }: { rows: Company[] }) {
  return (
    <div style={{ height: 600 }}>
      <DataGrid<Company>
        label="Companies"
        layoutKey="companies" // widths, order and frozen columns are remembered under this key
        columns={columns}
        rowCount={rows.length}
        getRow={(_group, i) => rows[i]}
        getRowId={(c) => c.id}
        onEdit={(edits) => save(edits)} // [{ rowId, columnId, value }]
      />
    </div>
  );
}
```

A column with `value` can be edited, pasted over and filled; without it, the
column is read-only. `onSort`, `onFilter`, `onGroup`, `onRename`, `onInsert`,
`onDuplicate`, `onDelete` and `onAddColumn` each turn on their entry in the
column menus. `calculations` turns on the footer.

`tree` nests sub-items under their rows. Pass the rows already in tree order,
each parent followed by the sub-items it shows; `tree.depth`, `tree.children`
and `tree.expanded` describe each row, and `tree.onToggle` is called from the
toggle in the first column or from ⌥→ and ⌥← on a row. The grid becomes a
`treegrid`, with `aria-level` and `aria-expanded` on its rows.

## Other layouts

`GridList`, `GridBoard`, `GridGallery` and `GridFeed` draw the same rows as
cards (`RowCard`). `GridCalendar` and `GridTimeline` place them by a date. The timeline groups its rows, shows more columns beside them,
colours bars, and draws dependencies as arrows that can be linked by dragging and removed with Delete.
`GridViewTabs` and `GridViewSettings` give a page Notion's views over any of
them. `GRID_LAYOUTS` lists the layouts with their names and icons.

## A database

`createDatabase` makes the grid a Notion database: typed properties (text, number, select, multi-select, status,
date and ranges, person, checkbox, URL, email, phone, files, relation, rollup, formula), each drawn and edited for its
type. Around it: `ViewToolbar` (filter with Notion's advanced and/or groups, sort, search) and `queryRows` to apply
it, `RowPeek` to open a row as a page (side peek, center peek, full page), `GridChart` (bars, line, donut), and a
Notion-style formula language (`compileFormula`).

```tsx
const db = createDatabase<Company>({ properties, get: (row, id) => row[id] ?? '' });
const shown = db.query(rows, { where, sorts, search });

<ViewToolbar properties={properties} where={where} sorts={sorts} search={search} onWhere={setWhere} onSorts={setSorts} onSearch={setSearch} />
<DataGrid columns={db.columns()} rowCount={shown.length} getRow={(_g, i) => shown[i]} … />
```

The Database guide in Storybook covers every type, filter and formula function.

## Other languages and right-to-left

Every string the grid draws comes from `gridMessages`, in English. `GridLocale` replaces any of them, and sets the
locale dates, numbers and currencies are written in (Intl; en-US by default). Only English ships in the package.

```tsx
<GridLocale locale="de-DE" messages={{ newRow: 'Neue Zeile', calculateColumn: (c) => `${c} berechnen` }}>
  <DataGrid … />
</GridLocale>
```

Give `createDatabase` the same `locale` and `messages` for the text it writes outside React (copies, search, the
footer). `GridCalendar` and `DayPicker` take `weekStartsOn`.

Right to left needs `dir="rtl"` on `<html>` (and Mantine's `DirectionProvider`). The stylesheets use logical
properties; the arrow keys, column resize and drags follow the screen (→ goes to the previous column right to
left), and the timeline's axis runs right to left, so ⌥← moves a bar later. Charts keep their axes left to right.

## Touch

Drags are pointer events, so they work with a finger too. A swipe scrolls the grid, a board, a calendar or a
timeline; holding a card, a bar, a column's header or a view's tab for a moment (400 ms) picks it up. Handles (a
row's ⋮⋮, a column's edge, a bar's edges and link dot) take the finger at once. With no hover, tapping a cell shows
its row's tools, and tapping a bar or a day shows its handles or its +. Touch styles sit behind
`@media (pointer: coarse)` and `@media (hover: none)`, so a mouse sees no change. The Grid overview in Storybook has
the details.

## Theming

Everything is drawn with Mantine's CSS variables, so it follows the app's
theme and colour scheme. The grid's background is `--app-surface` when the
page sets it, and Mantine's body colour otherwise.

Try it: `pnpm docs` at the repo root.
