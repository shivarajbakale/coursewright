# @shivarajbakale/grid

## 0.2.0

### Minor Changes

- 1372d23: Empty states that read as a place to start. With no rows, every layout centres its empty state in the space the rows would take: an icon, a title, a sentence and an action. A string `empty` becomes the title, with a New row button when `rowActions.onAdd` is given; `GridEmpty` (new) builds your own. The table also fills a parent that has a height but isn't a flex container.
